package com.emeka.bookshop_inventory;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookshopInventoryApplicationTests {

    @Test
    void contextLoads() {
    }

}
