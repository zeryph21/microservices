package com.emeka.bookshop_staff_management;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookshopStaffManagementApplicationTests {

    @Test
    void contextLoads() {
    }

}
